 // Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBqCxf6o6rlQKAp30HRkzkqyBWDev1VJ1E",
  authDomain: "real-estate-5c061.firebaseapp.com",
  projectId: "real-estate-5c061",
  storageBucket: "real-estate-5c061.appspot.com",
  messagingSenderId: "56430870257",
  appId: "1:56430870257:web:5b6904210c47d169f0b350"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);